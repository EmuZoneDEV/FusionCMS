<?php

$config['realmid'] = 1;
$config['minimize_groups_by_default'] = true;
$config['questionnr'] = 8; // Define how many questions should be enabled.
$config['info1'] = "How long have you been playing on Cold-Storm?";
$config['info2'] = "Have you ever been GM on a server before? can you tell us about your experience (if you have any experience)";
$config['info3'] = "Why do you think we should accept you as a GM?";
$config['info4'] = "If a player makes a ticket and say 'Paladins is overpower they one hit me' what do you do about that?";
$config['info5'] = "Tell us about your scripting experience. wich scripting language do you know?";
$config['info6'] = "What can we expect from you?";
$config['info7'] = "Tell us atleast 1 thing that we should add/change/delete on the server";
$config['info8'] = "Tell us some more about your self. if you have anything else to say, say it here!";
$config['info9'] = "How long have you been playing on Cold-Storm?";
$config['info10'] = "How long have you been playing on Cold-Storm?";
$config['info11'] = "How long have you been playing on Cold-Storm?";
$config['info12'] = "How long have you been playing on Cold-Storm?";
$config['info13'] = "How long have you been playing on Cold-Storm?";
$config['info14'] = "How long have you been playing on Cold-Storm?";
$config['info15'] = "How long have you been playing on Cold-Storm?";