Thanks for your Purchase dear customer!

-- [[ Top X Kill Streak Module ]] --
by AddeDev

How to Install? Follow the steps bellow:
1. Place "killstreak" module folder in ..\application\modules
2. Open and edit KillStreak_Config.php from killstreak\config
3. Change "MY REALM NAME" between quotes with your realm name
4. Change "3"; between quotes with your realm id
5. Change "characters"; between quotes with character database
6. Change "10"; between quotes with your preference.

____________________________________
Upcoming updates:
- Support multiple realms
- Support multiple emulators

Changelog:
* FIXED Queries
* A BIT OF CLEANUP
* CHANGED CODE STYLE
* BETTER CMS STYLE