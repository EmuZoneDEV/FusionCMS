<?php

$config['realmid'] = 1;