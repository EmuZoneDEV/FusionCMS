Credits
Sydns12 - Main code & Idea
Nirelz - Coverting to fusionCMS & updating with more features.

If you find a bug please email it to
Nirelz1993@hotmail.com
or add my skype; Nirelz_cassiopeia

Hope you like it.


ATTENTION
Import the char_trade.sql file into your characters table.