#### IMPORTANT ####

 ! This Plugin has been written by ChoMPi

 ! If you wish to contact me for work please send me an E-Mail with title "(Work) <your title>" to email address: chompibg@gmail.com
   or try finding me on skype: chikina6335
 
#### INSTALLATION ####

 1. Extract the contents of the archive usually on the desktop.

 2. Copy the contents of the folder Content into the root folder of your copy of FusionCMS.

 3. Open the folder named "SQL" from the extracted files from the module archive and import it into the FusionCMS database.

 4. Navigate to "User groups & permissions" on the Admin Panel side menu.

 5. Give your groups permissions to the UCP Manager module ACP Page.
    5. Click "Groups".
    5. Select your group usually "Owner" and click the pencil button (Edit).
    5. Locate the section "Roles (?)".
    5. Locate "User panel" in that section and thick the permission "administrate".

 6. You are done.
