#### INSTALLATION ####

 1. Extract the contents of the archive into the Root Directory of fusion CMS. (The root is the main folder where the index.php file is located)

 2. Add new menu link for the plugin from the admin panel. (FusionCMS Admin panel)
    2. Step 1. Enter title for the link (PVP Statistics etc...)
    2. Step 2. Enter URL like so: pvp_statistics
    2. step 3. Select one of the two possible menus Top or Side and submit.
 
 3. You are done.
