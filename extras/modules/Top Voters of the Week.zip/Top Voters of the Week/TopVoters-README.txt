#### IMPORTANT ####

 ! This Plugin has been written by ChoMPi
 
 ! To increase the number of voters shown visit the admin panel and find the plugin configuration section.

 ! If you wish to contact me for work please send me an E-Mail with title "(Work) <your title>" to email address: chompibg@gmail.com
   or try finding me on skype: chikina6335
 
#### INSTALLATION ####

 1. Extract the contents of the archive into the Root Directory of fusion CMS. (The root is the main folder where the index.php file is located)

 2. Add new sidebox for the plugin from the admin panel. (FusionCMS Admin panel)
    2. Step 1. Go to Sideboxes (Side Menu).
    2. Step 2. Click the "Create sidebox" button.
    2. step 3. Enter your desired "Headline". (example: Top Voters of the Week) 
    2. Step 4. Select "Sidebox module": Sidebox: Top Voters of the Week.
    2. Step 5. Click the "Submit sidebox" button.
 
 3. You are done.
