<?php
// use [id] token for lottery_id
$config['automatic_article_title'] = "Lottery edition #[id] has started! ";
$config['lottery_banner_for_news_article'] = false;

$config['default_vote_points_required_for_subscription'] = 5;

$config['default_donation_points_required_for_subscription'] = 0;
