<?php

$config['name_change_price'] = '5';
$config['race_change_price'] = '10';
$config['faction_change_price'] = '10';
$config['appearance_change_price'] = '10';