Instructions!



First put the "Immortal" Folder on your space in .../application/themes

Then put news.css into .../application/modules/news/css

Now put default.css in .../application/css

Now put the "images" Folder into .../application/modules/ucp

After all put read.css into .../application/modules/messages/css

One thing left, go to .../application/themes/Immortal and open the template.tpl with Editor,
now find the Line 14 and edit social links to your own! Lines are looking like these here:

			<header><a href="http://facebook.com" id="hand2" target="_blank"></a></header>
			<header><a href="http://youtube.com" id="hand3" target="_blank"></a></header>
			<header><a href="http://twitter.com" id="hand4" target="_blank"></a></header>



Now Theme is Ready to Use! Have Fun!