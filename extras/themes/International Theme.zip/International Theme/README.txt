Instructions!


First put the "international" Folder on your space in .../application/themes

Then put news.css into .../application/modules/news/css

Now put default.css in .../application/css

After all put read.css into .../application/modules/messages/css



Now Theme is Ready to Use! Have Fun!