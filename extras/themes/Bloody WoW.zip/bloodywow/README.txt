Instructions!



First put the Bloody Folder on your space in .../application/themes

Then put news.css into .../application/modules/news/css

At last put default.css in .../application/css


Now Theme is Ready to Use!