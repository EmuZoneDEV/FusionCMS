How to setup Loomar's theme for FusionCMS!


First put the "europewow" Folder on your space in .../application/themes

Now open the folder "++CSS FILES++" and do following steps:

-Put the news.css into .../application/modules/news/css
-Put default.css in .../application/css
-Put read.css into .../application/modules/messages/css


Now Theme is Ready for Use! Have Fun!


In folder ++PSD++ are all needed psd files.
Used Font: http://www.dafont.com/godofwar.font



